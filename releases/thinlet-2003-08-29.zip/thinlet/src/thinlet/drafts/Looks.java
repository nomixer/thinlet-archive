package thinlet.drafts;

public class Looks {
}