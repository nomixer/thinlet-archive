package thinlet.drafts;

import thinlet.*;

public class Chart {
	
	public void update(Thinlet thinlet, Object chart) {
		thinlet.repaint(chart);
	}
}