package org.thinlet.jme.event;

public class Cursor {

	public static final String HAND_CURSOR = null;
	public static final String DEFAULT_CURSOR = null;
	public static final String WAIT_CURSOR = null;
	public static final String E_RESIZE_CURSOR = null;
	public static final String S_RESIZE_CURSOR = null;
	public static final String N_RESIZE_CURSOR = null;
	public static final String NE_RESIZE_CURSOR = null;
	public static final String SE_RESIZE_CURSOR = null;
	public static final String SW_RESIZE_CURSOR = null;
	public static final String W_RESIZE_CURSOR = null;
	public static final String TEXT_CURSOR = null;
	public static String NW_RESIZE_CURSOR;

	public static Object getPredefinedCursor(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
