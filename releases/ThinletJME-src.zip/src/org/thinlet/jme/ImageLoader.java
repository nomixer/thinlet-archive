package org.thinlet.jme;

import javax.microedition.lcdui.Image;

public interface ImageLoader {

	Image getImage(String url);

}
